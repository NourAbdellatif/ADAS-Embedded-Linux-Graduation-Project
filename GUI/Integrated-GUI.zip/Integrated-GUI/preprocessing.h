#ifndef PREPROCESSING_H
#define PREPROCESSING_H

#define NUM_OF_CUSTOMER_FEATURES 1

#define CVISION_MODELS_DIRECTORY "/etc/Models"

#define CSS_FILE_PATH ":/Css-Styles/styles.css"

#define TRUE    1
#define FALSE   0
#define EMPTY   ""

#endif // PREPROCESSING_H
